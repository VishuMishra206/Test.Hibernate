package com.test.hibernate.test.hibernate;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Book")
public class Book 
{
  @Id
  private int bookid;
  private String bname;
  private String bauthor;
  private String bprice;
  
  public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public String getBauthor() {
	return bauthor;
}
public void setBauthor(String bauthor) {
	this.bauthor = bauthor;
}
public String getBprice() {
	return bprice;
}
public void setBprice(String bprice) {
	this.bprice = bprice;
}
@Override
public String toString() {
	return "Book [bookid=" + bookid + ", bname=" + bname + ", bauthor=" + bauthor + ", bprice=" + bprice + "]";
}

 
}
